#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include <stdio.h>
int wmain(int n,wchar_t **v){if(n!=2)return 2;HMODULE m=LoadLibraryW(v[1]);if(!m)return 3;typedef HRESULT (STDAPICALLTYPE *version_fn)(PCWSTR,LPWSTR*);union {FARPROC raw;version_fn fn;}p;p.raw=GetProcAddress(m,"GetAvailableCoreWebView2BrowserVersionString");LPWSTR version=NULL;HRESULT h=p.fn?p.fn(NULL,&version):E_FAIL;wprintf(L"Default selected WebView2 Runtime=%ls HRESULT=0x%08lx\n",version?version:L"(none)",(unsigned long)h);if(version)CoTaskMemFree(version);FreeLibrary(m);return FAILED(h)?1:0;}
