@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
set VSLANG=1033
cmake -S . -B "build/visual-polish-20261007/baseline" -G Ninja -DCMAKE_BUILD_TYPE=Release -DUI_FRAMEWORK_ENABLE_WEBVIEW2=ON "-DUI_OSMESA_LIBRARY=D:/应用软件框架/应用层序框架/.deps/mesa-24.3.4/x64/osmesa.dll" > "build/visual-polish-20261007/baseline-configure.log" 2>&1
if errorlevel 1 exit /b 1
cmake --build "build/visual-polish-20261007/baseline" --parallel 8 > "build/visual-polish-20261007/baseline-build.log" 2>&1
exit /b %errorlevel%
