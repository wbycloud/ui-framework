@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
cl /nologo /MD /utf-8 /std:c11 /DUI_FRAMEWORK_BUILD_SHARED /Iinclude tests/light_glyph_padding.c "build/visual-polish-20261007/baseline/ui_framework_runtime.lib" /Fe:"build/visual-polish-20261007/baseline/glyph-red.exe" /Fo:"build/visual-polish-20261007/glyph-red.obj" > "build/visual-polish-20261007/glyph-red-build.log" 2>&1
if errorlevel 1 exit /b 1
"build/visual-polish-20261007/baseline/glyph-red.exe" > "build/visual-polish-20261007/glyph-red.log" 2>&1
exit /b %errorlevel%
