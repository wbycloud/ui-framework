import zipfile
from pathlib import Path
p=Path(__file__).parent
for z,d in [("framework-baseline-source.zip","framework-baseline-source"),("business-source.zip","business-source")]:
 with zipfile.ZipFile(p/z) as a:a.extractall(p/d)
print("Current sources copied into new independent directories")
