@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
cl /nologo /std:c11 /utf-8 build\visual-polish-20261007\runtime-version.c ole32.lib /Fe:build\visual-polish-20261007\runtime-version.exe /Fo:build\visual-polish-20261007\runtime-version.obj
exit /b %errorlevel%
