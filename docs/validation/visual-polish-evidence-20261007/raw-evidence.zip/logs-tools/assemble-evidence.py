import hashlib,json,shutil,zipfile
from pathlib import Path
from PIL import Image
work=Path(__file__).parent
repo=work.parent.parent
dest=repo/"docs/validation/visual-polish-evidence-20261007"
dest.mkdir(parents=True,exist_ok=True)
(dest/"screenshots").mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
gallery={}
for phase in ("before","after"):
    mappings={f"{engine}-{name}":f"{engine}-{name}" for engine in ("light","runtime") for name in ("host-light","host-dark","host-dpi-96","host-dpi-144","host-dpi-192","narrow","assistant","color-picker","enum")}
    mappings.update({f"business-{theme}":f"desktop-app-business-{theme}" for theme in ("light","dark","ai")})
    mappings.update({f"features-wgl-{theme}":f"features-business-{theme}" for theme in ("light","dark","ai")})
    for label,name in mappings.items():
        src=work/phase/(name+".bmp"); out=dest/"screenshots"/f"{phase}-{label}.png"
        im=Image.open(src).convert("RGB");im.save(out)
        assert Image.open(out).convert("RGB").tobytes()==im.tobytes()
        gallery[out.relative_to(dest).as_posix()]={"source":src.relative_to(work).as_posix(),"dimensions":list(im.size),"bmp_sha256":sha(src.read_bytes()),"png_sha256":sha(out.read_bytes()),"pixels_lossless":True,"app":"api7_fixture" if label.startswith(("light","runtime")) else "klayoutc abc8d870" if label.startswith("business") else "framework_features actual WGL","product":"43587c3" if phase=="before" else "6a0170a"}
for label in mappings:
    assert gallery[f"screenshots/before-{label}.png"]["dimensions"]==gallery[f"screenshots/after-{label}.png"]["dimensions"],label
(dest/"screenshots.json").write_text(json.dumps(gallery,indent=2,ensure_ascii=False)+"\n",encoding="utf8")
for n in ("artifact-identity.json","final-source-before-commit.json","public-current-hashes.json","environment-final.json","current-plan.json","business-readonly-hashes-before.json","business-readonly-hashes-after.json"):
    shutil.copyfile(work/n,dest/n)
files={}
def add(src,name):
    b=src.read_bytes(); files[name]={"bytes":len(b),"sha256":sha(b)}
    return b
with zipfile.ZipFile(dest/"raw-evidence.zip","w",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for src in sorted(work.iterdir()):
        if src.is_file() and src.suffix.lower() in (".log",".err",".cmd",".c",".inc",".py",".json",".xml"):
            name="logs-tools/"+src.name;z.writestr(name,add(src,name))
    for phase in ("before","after","native-mouse"):
        for src in sorted((work/phase).glob("*.bmp")):
            name="raw-captures/"+phase+"/"+src.name;z.writestr(name,add(src,name))
    for phase in ("diagnostic-wrong-fixture","diagnostic-root-output"):
        for src in sorted((work/phase).rglob("*")):
            if src.is_file():
                name="diagnostic-only/"+phase+"/"+str(src.relative_to(work/phase)).replace("\\","/");z.writestr(name,add(src,name))
    for phase in ("baseline","after","business-before","business-after"):
        for n in ("CMakeCache.txt","CTestTestfile.cmake","Testing/Temporary/LastTest.log","Testing/Temporary/LastTestsFailed.log","regression_version.h"):
            src=work/phase/n
            if src.exists():
                name="run-config/"+phase+"/"+n;z.writestr(name,add(src,name))
    src=work/"business-source/framework-sdk.lock.json";z.writestr("business-copied-original-lock.json",add(src,"business-copied-original-lock.json"))
    for src in sorted((work/"business-after").glob("*.bmp")):
        name="raw-captures/business-final/"+src.name;z.writestr(name,add(src,name))
    src=work/"business-after/workflow-pages.gds"
    if src.exists():z.writestr("fixtures/workflow-pages.gds",add(src,"fixtures/workflow-pages.gds"))
with zipfile.ZipFile(dest/"raw-evidence.zip") as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(files)
    for n,h in files.items(): assert sha(z.read(n))==h["sha256"],n
archive=(dest/"raw-evidence.zip").read_bytes()
index={"archive":{"bytes":len(archive),"sha256":sha(archive),"crc_verified":True},"files":files,"gallery":gallery,"classification":{"raw-captures/before/webview2-*":"Runtime sandbox not ready; diagnostic only, not gallery","raw-captures/*/app-business-*":"PrintWindow omits native GL; diagnostic only","diagnostic-only/diagnostic-wrong-fixture":"Incorrect fixture path yielded empty business model, not accepted screenshot","raw-captures/native-mouse":"Minimal mouse fixture evidence, not complete-window visual substitute"}}
(dest/"index.json").write_text(json.dumps(index,indent=2,ensure_ascii=False)+"\n",encoding="utf8")
print(json.dumps({"gallery":len(gallery),"raw_files":len(files),"archive_bytes":len(archive),"archive_sha256":sha(archive),"crc":"PASS"},ensure_ascii=False))
