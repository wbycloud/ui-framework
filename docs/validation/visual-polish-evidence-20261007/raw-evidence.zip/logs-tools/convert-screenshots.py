from pathlib import Path
from PIL import Image
import hashlib,json
root=Path(__file__).parent
records={}
for phase in ("before","after"):
 for f in (root/phase).glob("*.bmp"):
  p=f.with_suffix(".png")
  im=Image.open(f).convert("RGB");im.save(p)
  assert Image.open(p).convert("RGB").tobytes()==im.tobytes()
  records[str(p.relative_to(root))]={"bytes":p.stat().st_size,"dimensions":im.size,"bmp_sha256":hashlib.sha256(f.read_bytes()).hexdigest(),"png_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"pixels_lossless":True}
(root/"screenshots.json").write_text(json.dumps(records,indent=2),encoding="utf8")
print(len(records),"actual screenshots converted without pixel changes")
