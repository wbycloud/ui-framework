@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
cmake --build build/visual-polish-20261007/after --parallel 8 > build/visual-polish-20261007/incremental.log 2>&1
exit /b %errorlevel%
