@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
cl /nologo /std:c11 /utf-8 /MD /DUI_FRAMEWORK_BUILD_SHARED /I include build\visual-polish-20261007\runtime-probe.c build\visual-polish-20261007\baseline\ui_framework_runtime.lib user32.lib ole32.lib /Fe:build\visual-polish-20261007\baseline\runtime-probe.exe /Fo:build\visual-polish-20261007\runtime-probe.obj > build\visual-polish-20261007\runtime-probe-build.log 2>&1
exit /b %errorlevel%
