from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd()
e=root/"build/browser-host-evidence"
destination=root/"docs/validation/browser-host-evidence.zip"
sources={}
for p in e.iterdir():
 if p.is_file() and p.name not in ("archive-summary.json",):sources["evidence/"+p.name]=p
for folder,pattern in [("build/ci-webview2/session0-control","*"),("docs/validation","browser-host-*.png")]:
 for p in (root/folder).glob(pattern):
  if p.is_file():sources[folder+"/"+p.name]=p
for name in ["CMakeLists.txt","examples/framework_host/main.c","examples/framework_host/browser_shell.h","examples/framework_host/host.html","tests/browser_host.c","tests/web_host_frontend.c"]:
 sources["source/"+name]=root/name
index={name:{"size":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(sources.items())}
with zipfile.ZipFile(destination,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(sources.items()):z.writestr(name,p.read_bytes())
 z.writestr("index.json",json.dumps(index,indent=2,ensure_ascii=False))
with zipfile.ZipFile(destination) as z:
 assert set(z.namelist())==set(index)|{"index.json"}
 for name,value in index.items():
  data=z.read(name);assert len(data)==value["size"] and hashlib.sha256(data).hexdigest()==value["sha256"]
print(f"Archive {len(index)} original-byte files; index/bytes verification PASS; SHA256 "+hashlib.sha256(destination.read_bytes()).hexdigest())