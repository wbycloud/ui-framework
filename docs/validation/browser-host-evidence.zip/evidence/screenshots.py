from pathlib import Path
from PIL import Image
import hashlib, json
root=Path.cwd()
e=root/"build/browser-host-evidence"
out=root/"docs/validation"
result=[]
for before,after in [("before-light.bmp","browser-host-before-light.png"),("before-dark.bmp","browser-host-before-dark.png"),("delivery-light.bmp","browser-host-after-light.png"),("delivery-dark.bmp","browser-host-after-dark.png"),("delivery-gl.bmp","browser-host-after-gl.png")]:
 im=Image.open(e/before).convert("RGB")
 im.save(out/after)
 assert im.tobytes()==Image.open(out/after).convert("RGB").tobytes()
 result.append({"source":before,"png":after,"size":im.size,"bmp_sha256":hashlib.sha256((e/before).read_bytes()).hexdigest(),"png_sha256":hashlib.sha256((out/after).read_bytes()).hexdigest(),"pixel_equal":True})
(e/"screenshots.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print("Five real PrintWindow images encoded to PNG; RGB pixel equality PASS")