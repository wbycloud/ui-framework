$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$ctest='C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
& $ctest --test-dir (Join-Path $taskRoot 'build/ci-webview2') --output-on-failure --output-junit (Join-Path $taskRoot 'build/browser-host-evidence/focused-desktop.xml') -R '^(ui_browser_host|ui_web_host_frontend|ui_framework_features_host|ui_menu_desktop|ui_generic_web_host|ui_component_resilience)$' > (Join-Path $taskRoot 'build/browser-host-evidence/focused-desktop.log') 2>&1
$taskCode=$LASTEXITCODE
Set-Content -LiteralPath (Join-Path $taskRoot 'build/browser-host-evidence/focused-desktop.exit') -Value $taskCode
exit $taskCode
