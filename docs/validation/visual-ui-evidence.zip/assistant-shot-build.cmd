@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
rc /nologo /I "%UI_VISUAL_ROOT%\build\ci-webview2\generated" /fo "%UI_VISUAL_ROOT%\build\visual-ui-evidence\host-shot.res" "%UI_VISUAL_ROOT%\build\ci-webview2\generated\host.rc"
if errorlevel 1 exit /b 1
cl /nologo /TC /utf-8 /W4 /WX /MT /D_CRT_SECURE_NO_WARNINGS /DUI_FRAMEWORK_BUILD_SHARED /I "%UI_VISUAL_ROOT%\include" /I "%UI_VISUAL_ROOT%\build\ci-webview2\generated" "%UI_VISUAL_ROOT%\build\visual-ui-evidence\assistant-shot.c" /Fo"%UI_VISUAL_ROOT%\build\visual-ui-evidence\assistant-shot.obj" /Fe"%UI_VISUAL_ROOT%\build\ci-webview2\visual-assistant-shot.exe" /link "%UI_VISUAL_ROOT%\build\visual-ui-evidence\host-shot.res" "%UI_VISUAL_ROOT%\build\ci-webview2\ui_framework_runtime.lib" user32.lib gdi32.lib comdlg32.lib shell32.lib dwmapi.lib ole32.lib
exit /b %errorlevel%
