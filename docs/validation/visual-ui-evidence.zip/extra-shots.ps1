﻿$ErrorActionPreference='Continue'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$b=Join-Path $root 'build/ci-webview2'
& (Join-Path $b 'visual-assistant-shot.exe') (Join-Path $b 'minimal_eda.uapp') (Join-Path $PSScriptRoot 'after-eda') *> (Join-Path $PSScriptRoot 'after-eda.log')
$LASTEXITCODE | Set-Content (Join-Path $PSScriptRoot 'after-eda.exit')
& (Join-Path $b 'ui_menu_desktop_test.exe') (Join-Path $b 'framework_features.uapp') (Join-Path $PSScriptRoot 'after-menu') *> (Join-Path $PSScriptRoot 'after-menu.log')
$LASTEXITCODE | Set-Content (Join-Path $PSScriptRoot 'after-menu.exit')
