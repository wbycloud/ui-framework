from pathlib import Path
import hashlib,json,subprocess,zipfile
from PIL import Image
root=Path.cwd();ev=root/'build/visual-ui-evidence';out=root/'docs/validation/visual-ui-evidence.zip'
assert not out.exists(),'Evidence archive already exists; use a new reviewed path.'
text_ext={'.log','.xml','.json','.exit','.txt','.c','.h','.patch','.diff','.py','.ps1','.cmd','.md'}
image_prefix=('before-','release-','after-menu-')
files=[p for p in sorted(ev.iterdir()) if p.is_file() and (p.suffix in text_ext or p.suffix in {'.bmp','.png'} and (p.name.startswith(image_prefix) or p.name=='invisible-cell-red.bmp'))]
pixel_all=json.loads((ev/'screenshot-pixels.json').read_text(encoding='utf-8'))
pixel_archive=[x for x in pixel_all if x['bmp'].startswith(image_prefix)]
for x in pixel_archive:
    bmp=Image.open(ev/x['bmp']).convert('RGB');png=Image.open(ev/x['png']).convert('RGB')
    assert bmp.size==png.size and bmp.tobytes()==png.tobytes(),x['bmp']
    assert hashlib.sha256(png.tobytes()).hexdigest()==x['pixels_sha256'],x['png']
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only','7e87f55','HEAD'],text=True).splitlines()
source=[p for p in changed if not p.startswith('docs/') and p not in {'README.md','CHANGELOG.md'}]
source_data={'source_commit':commit,'local_commits':subprocess.check_output(['git','log','--format=%H %s','7e87f55..HEAD'],text=True).splitlines(),'dirty_at_archive':subprocess.check_output(['git','status','--porcelain'],text=True).splitlines(),'source_files':[]}
source_data['source_files']=[{'path':p,'bytes':(root/p).stat().st_size,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in source]
readme='''Framework-owned visual delivery / 2026-10-06
Source: 01c87801aa86d70759c45e333af7ecc6e31699fc (API7/ABI1)
Core full local matrix: 0b306e6, 63 PASS / 1 physical SKIP, 376.85 s.
Subsequent host units: c5df8c0 14/14 68.41 s; 7d81b8f 14/14 68.14 s; 01c8780 14/14 67.76 s.
Native/light same-binary llvmpipe: 21/42 PASS respectively, each 1 physical SKIP.
Initial Mesa D3D12 crashes remain failures, not a claimed product fix.
No GitHub run, Session0, strict no-login, physical IME/mixed monitors/DWM or business acceptance is claimed.
Before: 7e87f55 + inherited-ai.patch + new screenshot driver; baseline binary hashes were not captured.
Final screenshots: release-* and release-snapshot-binaries.json, actual application DLLs/Runtime/GL.
Menu screenshot: after-menu-* from 0b306e6; subsequent host-only units did not change menu product code.
BMP/PNG are raw real capture and lossless conversion; screenshot-pixels.json contains only archived images.
local-screenshot-inventory.json also lists intermediate local images omitted here; it is an inventory, not a claim those files are archived.
Logs/XML/LastTest/scripts preserve original bytes (some UTF-16), failures and precommit dirty identities.
params-setup-diagnostic-notes.txt explicitly records a reused diagnostic filename, not an original preserved log.
sha256.json hashes every archive member except itself. No application binary, frozen SDK or original package is embedded.
Archived scripts record the original invocations. They contain fixed result paths: do not rerun unchanged over evidence.
For replay use the build/validation document commands and fresh build/evidence directories/prefixes.
Source files are included for code review; canonical history is the local commits in source-commit.json.
'''
index=[]
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(name,data):
        assert name not in z.namelist(),name
        z.writestr(name,data)
        index.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    for p in files:
        name='local-screenshot-inventory.json' if p.name=='screenshot-pixels.json' else p.name
        add(name,p.read_bytes())
    add('screenshot-pixels.json',json.dumps(pixel_archive,indent=2).encode('utf-8'))
    add('source-commit.json',json.dumps(source_data,indent=2,ensure_ascii=False).encode('utf-8'))
    add('ARCHIVE-README.txt',readme.encode('utf-8'))
    for p in source:add('source-files/'+p,(root/p).read_bytes())
    for p in sorted((root/'docs/validation').glob('visual-ui-*.png')):add('display/'+p.name,p.read_bytes())
    add('sha256.json',json.dumps(index,indent=2).encode('utf-8'))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    table=json.loads(z.read('sha256.json'))
    assert len(z.namelist())==len(table)+1
    for item in table:
        data=z.read(item['path']);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
summary={'file':str(out.relative_to(root)),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(table)+1,'images_pixel_verified':len(pixel_archive),'source_commit':commit}
(ev/'archive-integrity.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
