﻿$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$ctest='C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
$build=Join-Path $taskRoot 'build/ci-webview2'
$evidence=Join-Path $taskRoot 'build/visual-ui-evidence'
$identity=[ordered]@{commit=(& git -C $taskRoot rev-parse HEAD);status=(@(& git -C $taskRoot status --porcelain));utc=[DateTime]::UtcNow.ToString('o');os=[Environment]::OSVersion.VersionString;ctest=(& $ctest --version|Select-Object -First 1);binaries=@(Get-ChildItem -LiteralPath $build -File | Where-Object { $_.Extension -in @('.exe','.dll','.uapp') }|ForEach-Object{[ordered]@{name=$_.Name;sha256=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([IO.File]::ReadAllBytes($_.FullName))).Replace('-','')}});runtime=(Get-Item 'C:/Program Files (x86)/Microsoft/EdgeWebView/Application/154.0.4258.53/msedgewebview2.exe').VersionInfo.FileVersion}
$identity|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $evidence 'params-fixed-identity.json') -Encoding UTF8
& $ctest --test-dir $build --show-only=json-v1 | Set-Content -LiteralPath (Join-Path $evidence 'params-fixed-plan.json') -Encoding UTF8
$ErrorActionPreference='Continue'
& $ctest --test-dir $build --output-on-failure -R "^(ui_light_web_parity|ui_visual_ui_light|ui_visual_ui_webview2|ui_light_scroll|ui_component_scroll|ui_web_host_frontend|ui_browser_host)$" --output-junit (Join-Path $evidence 'params-fixed.xml') 2>&1 | Out-File -LiteralPath (Join-Path $evidence 'params-fixed.log') -Encoding utf8
$taskCode=$LASTEXITCODE
$ErrorActionPreference='Stop'
Copy-Item -LiteralPath (Join-Path $build 'Testing/Temporary/LastTest.log') -Destination (Join-Path $evidence 'params-fixed-LastTest.log')
Set-Content -LiteralPath (Join-Path $evidence 'params-fixed.exit') -Value $taskCode
exit $taskCode
