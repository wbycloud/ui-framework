Framework-owned visual delivery / 2026-10-06
Source: 01c87801aa86d70759c45e333af7ecc6e31699fc (API7/ABI1)
Core full local matrix: 0b306e6, 63 PASS / 1 physical SKIP, 376.85 s.
Subsequent host units: c5df8c0 14/14 68.41 s; 7d81b8f 14/14 68.14 s; 01c8780 14/14 67.76 s.
Native/light same-binary llvmpipe: 21/42 PASS respectively, each 1 physical SKIP.
Initial Mesa D3D12 crashes remain failures, not a claimed product fix.
No GitHub run, Session0, strict no-login, physical IME/mixed monitors/DWM or business acceptance is claimed.
Before: 7e87f55 + inherited-ai.patch + new screenshot driver; baseline binary hashes were not captured.
Final screenshots: release-* and release-snapshot-binaries.json, actual application DLLs/Runtime/GL.
Menu screenshot: after-menu-* from 0b306e6; subsequent host-only units did not change menu product code.
BMP/PNG are raw real capture and lossless conversion; screenshot-pixels.json contains only archived images.
local-screenshot-inventory.json also lists intermediate local images omitted here; it is an inventory, not a claim those files are archived.
Logs/XML/LastTest/scripts preserve original bytes (some UTF-16), failures and precommit dirty identities.
params-setup-diagnostic-notes.txt explicitly records a reused diagnostic filename, not an original preserved log.
sha256.json hashes every archive member except itself. No application binary, frozen SDK or original package is embedded.
Archived scripts record the original invocations. They contain fixed result paths: do not rerun unchanged over evidence.
For replay use the build/validation document commands and fresh build/evidence directories/prefixes.
Source files are included for code review; canonical history is the local commits in source-commit.json.
