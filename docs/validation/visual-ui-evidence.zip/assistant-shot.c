/* Screenshot harness includes the actual host and unchanged visual helpers. */
#define wmain visual_test_main
#include "../../tests/visual_ui.c"
#undef wmain
int wmain(int argc,wchar_t **argv)
{
 host_window_t h={0}; HWND root; ui_app_instance_info_t info={0};host_action_t a={0};char id[32];uint64_t first,second;
 if(argc<3)return 2;CHECK(ui_framework_initialize()==UI_STATUS_OK);root=create_host(&h,GetModuleHandleW(NULL));CHECK(root!=NULL);if(!root)return 1;
 ShowWindow(root,SW_SHOW);SetWindowPos(root,HWND_TOPMOST,40,40,1200,800,0);
 open_path(&h,argv[1]);pump(100);first=ui_workspace_active(h.workspace);open_path(&h,argv[1]);pump(100);second=ui_workspace_active(h.workspace);
 CHECK(first&&second&&first!=second);CHECK(get_instance(&h,first,&info));CHECK(info.host->surfaces!=NULL);
 CHECK(press(h.view,"assistant-toggle"));pump(30);
 snprintf(id,sizeof(id),"%llu",(unsigned long long)first);a.action="select-target";a.id=id;process_action(&h,&a);a.action="select-command";a.command="eda.add_block";process_action(&h,&a);pump(30);
 CHECK(press(h.view,"invoke"));pump(100);CHECK(h.target==first&&strstr(h.result_summary,"操作完成")!=NULL);
 host_frame(root,argv[2],L"assistant-operation");
 CHECK(press(h.view,"advanced-toggle"));pump(20);host_frame(root,argv[2],L"assistant-advanced");
 CHECK(press(h.view,"advanced-toggle"));CHECK(press(h.view,"assistant-toggle"));pump(30);CHECK(!assistant_visible(&h));
 for(int dark=0;dark<2;++dark){h.dark=dark;layout(&h);pump(70);host_frame(root,argv[2],dark?L"gl-dark":L"gl-light");}
 SendMessageW(root,WM_CLOSE,0,0);pump(100);CHECK(!IsWindow(root));printf("Actual EDA / assistant snapshots: %d failures\n",failures);return failures?1:0;
}
