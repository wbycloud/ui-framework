from pathlib import Path
from PIL import Image
import hashlib,json
root=Path.cwd();ev=root/'build/visual-ui-evidence'
items=[]
for p in sorted(ev.glob('*.bmp')):
    if not p.name.startswith(('before-','after-','final-light-','final-webview2-','final-eda-','delivery-light-','delivery-webview2-','delivery-eda-','release-light-','release-webview2-','release-eda-')):continue
    image=Image.open(p).convert('RGB');out=p.with_suffix('.png');image.save(out)
    assert Image.open(out).convert('RGB').tobytes()==image.tobytes(),p
    items.append(dict(bmp=p.name,png=out.name,width=image.width,height=image.height,pixels_sha256=hashlib.sha256(image.tobytes()).hexdigest(),bmp_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),png_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
(ev/'screenshot-pixels.json').write_text(json.dumps(items,indent=2),encoding='utf-8')
print('Actual BMP -> PNG RGB identical:',len(items))
