﻿$ErrorActionPreference='Continue'
foreach($name in @('native-software','light-software')) { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot ($name+'.ps1')); $LASTEXITCODE | Set-Content (Join-Path $PSScriptRoot ($name+'-launcher.exit')) }
