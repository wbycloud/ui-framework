﻿﻿$ErrorActionPreference='Continue'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$b=Join-Path $root 'build/ci-webview2'
foreach($mode in @('light','webview2')) { & (Join-Path $b 'ui_visual_ui_test.exe') (Join-Path $b 'api7_fixture.uapp') (Join-Path $root '.deps/mesa-24.3.4/x64/osmesa.dll') $mode (Join-Path $PSScriptRoot ('delivery-'+$mode)) *> (Join-Path $PSScriptRoot ('delivery-'+$mode+'.log')); $LASTEXITCODE | Set-Content (Join-Path $PSScriptRoot ('delivery-'+$mode+'.exit')) }


& (Join-Path $b 'visual-assistant-shot.exe') (Join-Path $b 'minimal_eda.uapp') (Join-Path $PSScriptRoot 'delivery-eda') *> (Join-Path $PSScriptRoot 'delivery-eda.log')
$LASTEXITCODE | Set-Content (Join-Path $PSScriptRoot 'delivery-eda.exit')
