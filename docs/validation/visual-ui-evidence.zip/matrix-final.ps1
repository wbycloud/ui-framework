﻿$ErrorActionPreference='Continue'
foreach($name in @('final','native','light')) { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot ($name+'.ps1')); $LASTEXITCODE | Set-Content (Join-Path $PSScriptRoot ($name+'-launcher.exit')) }
