@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
cmake --build "%UI_VISUAL_ROOT%\build\ci-webview2" > "%UI_VISUAL_ROOT%\build\visual-ui-evidence\frozen-build-webview2.log" 2>&1
if errorlevel 1 exit /b 1
cmake --build "%UI_VISUAL_ROOT%\build\ci-native" > "%UI_VISUAL_ROOT%\build\visual-ui-evidence\frozen-build-native.log" 2>&1
if errorlevel 1 exit /b 1
cmake --build "%UI_VISUAL_ROOT%\build\ci-light" > "%UI_VISUAL_ROOT%\build\visual-ui-evidence\frozen-build-light.log" 2>&1
exit /b %errorlevel%
