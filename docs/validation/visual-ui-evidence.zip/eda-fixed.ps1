﻿$ErrorActionPreference='Continue'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$b=Join-Path $root 'build/ci-webview2'
& (Join-Path $b 'visual-assistant-shot.exe') (Join-Path $b 'minimal_eda.uapp') (Join-Path $PSScriptRoot 'after-eda-fixed') *> (Join-Path $PSScriptRoot 'after-eda-fixed.log')
$LASTEXITCODE | Set-Content (Join-Path $PSScriptRoot 'after-eda-fixed.exit')
