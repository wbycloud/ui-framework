﻿$ErrorActionPreference='Continue'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$b=Join-Path $root 'build/ci-webview2'
$e=$PSScriptRoot
foreach($mode in @('light','webview2')) { & (Join-Path $b 'ui_visual_ui_test.exe') (Join-Path $b 'api7_fixture.uapp') (Join-Path $root '.deps/mesa-24.3.4/x64/osmesa.dll') $mode (Join-Path $e ('before-'+$mode)) --baseline *> (Join-Path $e ('before-'+$mode+'.log')); $LASTEXITCODE | Set-Content (Join-Path $e ('before-'+$mode+'.exit')) }
& 'C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe' --test-dir $b --output-on-failure -R '^(ui_browser_host|ui_web_host_frontend)$' --output-junit (Join-Path $e 'inherited-ai.xml') *> (Join-Path $e 'inherited-ai.log')
$LASTEXITCODE | Set-Content (Join-Path $e 'inherited-ai.exit')
Copy-Item (Join-Path $b 'Testing/Temporary/LastTest.log') (Join-Path $e 'inherited-ai-LastTest.log')
& (Join-Path $b 'ui_visual_ui_test.exe') (Join-Path $b 'api7_fixture.uapp') (Join-Path $root '.deps/mesa-24.3.4/x64/osmesa.dll') light *> (Join-Path $e 'visual-red.log'); $LASTEXITCODE | Set-Content (Join-Path $e 'visual-red.exit')
