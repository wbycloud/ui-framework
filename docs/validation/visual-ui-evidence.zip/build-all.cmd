@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cmake --build "%UI_VISUAL_ROOT%\build\ci-webview2"  > "%UI_VISUAL_ROOT%\build\visual-ui-evidence\build-all.log" 2>&1
exit /b %errorlevel%
