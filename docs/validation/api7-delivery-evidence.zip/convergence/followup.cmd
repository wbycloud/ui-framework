@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
"%UI_FOLLOWUP_PS%" -NoProfile -File "%UI_FOLLOWUP_FILE%"
exit /b %errorlevel%
