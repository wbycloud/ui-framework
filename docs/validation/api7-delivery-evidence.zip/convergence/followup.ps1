$ErrorActionPreference='Stop'
$root='D:\应用软件框架\应用层序框架'; Set-Location -LiteralPath $root
$env:PATH='C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;'+$env:PATH
$build=Join-Path $root 'build/ci-webview2'; $out=Join-Path $root 'build/api7-convergence'
$provider=Join-Path $root '.deps/mesa-24.3.4/x64/osmesa.dll'
$record=[ordered]@{commit=(& git rev-parse HEAD); dirty=[bool]@(& git status --porcelain).Count; started=(Get-Date).ToString('o'); results=@(); files=@()}
foreach($name in @('ui_framework.dll','ui_api7_fixture.dll','api7_fixture.uapp','ui_api7_integration_test.exe','ui_api5_integration_test.exe','ui_api5_native_host_test.exe')){
    $record.files += [ordered]@{name=$name; sha256=(Get-FileHash "$build/$name").Hash.ToLowerInvariant()}
}
foreach($mode in @('fast','ready')){
    $env:UI_RUNTIME_CYCLES='64'; $env:UI_RUNTIME_READY_REOPENS=if($mode -eq 'ready'){'1'}else{$null}
    & "$build/ui_api7_integration_test.exe" "$build/api7_fixture.uapp" $provider webview2 *> "$out/runtime-$mode-64.log"
    $code=$LASTEXITCODE
    $record.results += [ordered]@{mode=$mode; exit=$code; completed=(Get-Date).ToString('o')}
    $record | ConvertTo-Json -Depth 6 | Set-Content "$out/followup-progress.json"
    if($code){exit $code}
}
$env:UI_RUNTIME_CYCLES=$null; $env:UI_RUNTIME_READY_REOPENS=$null
Copy-Item -LiteralPath "$build/CMakeCache.txt" -Destination "$out/matrix-webview2-cache.txt"
& cmake -S . -B $build "-DUI_LEGACY_EDA_PACKAGE=$root/build/web-shell/baseline/minimal_eda.uapp" "-DUI_LEGACY_API2_PACKAGE=$root/build/api3/baseline/web_counter.uapp" "-DUI_LEGACY_COMPONENT_PACKAGE=$root/build/fw-next/baseline/generic_components.uapp" "-DUI_LEGACY_API4_PACKAGE=$root/build/api5-evidence/original-api4-framework_features.uapp" "-DUI_LEGACY_API5_PACKAGE=$root/build/api6-evidence/original-api5-fixture.uapp" "-DUI_LEGACY_API6_PACKAGE=$root/build/api7-evidence/original-api6-fixture.uapp" *> "$out/original-configure.log"
if($LASTEXITCODE){exit $LASTEXITCODE}
& cmake --build $build *> "$out/original-build.log"
if($LASTEXITCODE){exit $LASTEXITCODE}
& ctest --test-dir $build -R 'ui_original_api[245]_package|ui_api3_original_package|ui_legacy_api6_|ui_application_versions' --no-tests=error --output-on-failure --output-junit "$out/original-tests.xml" *> "$out/original-tests.log"
$code=$LASTEXITCODE
Copy-Item -LiteralPath "$build/Testing/Temporary/LastTest.log" -Destination "$out/original-output.log"
& ctest --test-dir $build --show-only=json-v1 > "$out/original-test-plan.json"
. ./tools/windows-ci-checks.ps1
[xml]$xml=Get-Content "$out/original-tests.xml" -Raw
@(Get-UiCiOriginalPackages $build $xml) | ConvertTo-Json -Depth 6 | Set-Content "$out/original-packages.json"
$record.results += [ordered]@{mode='six-original-packages'; exit=$code; completed=(Get-Date).ToString('o')}
$record | ConvertTo-Json -Depth 6 | Set-Content "$out/followup-progress.json"
exit $code
