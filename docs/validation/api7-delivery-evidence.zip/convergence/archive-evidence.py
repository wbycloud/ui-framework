from pathlib import Path
import zipfile,hashlib,json
root=Path.cwd(); local=root/'build/api7-convergence'; entries=[]
for path in sorted(local.rglob('*')):
    if path.is_file() and 'drafts' not in path.relative_to(local).parts and path.name != 'archive-check.log':
        entries.append((path,'convergence/'+path.relative_to(local).as_posix()))
for row in ['native','light','osmesa','webview2']:
    folder=root/f'build/ci-evidence-{row}'
    for path in sorted(folder.rglob('*')):
        if path.is_file():entries.append((path,'matrix/'+row+'/'+path.relative_to(folder).as_posix()))
index={'source_commit':'e4a33bf5142550d52e85b728670813ee6cec7390','hosted_ci':False,'files':[]}
archive=root/'docs/validation/api7-delivery-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for path,name in entries:
        raw=path.read_bytes(); out.writestr(name,raw)
        index['files'].append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    out.writestr('evidence-index.json',json.dumps(index,ensure_ascii=False,indent=2).encode('utf-8'))
with zipfile.ZipFile(archive) as inp:
    assert inp.testzip() is None
    for item in index['files']:
        assert hashlib.sha256(inp.read(item['path'])).hexdigest()==item['sha256'],item
    manifests=[json.loads(inp.read(f'matrix/{r}/manifest.json')) for r in ['native','light','osmesa','webview2']]
    assert all(m['commit']==index['source_commit'] and not m['sourceDirty'] and not m['githubRunId'] for m in manifests)
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
print(f'ZIP byte integrity PASS: {len(entries)} evidence files, {archive.stat().st_size} bytes, sha256={sha}')
(root/'build/api7-convergence/archive-check.log').write_text(f'{len(entries)} files checked; zip SHA256={sha}\n',encoding='utf-8')
