$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\应用软件框架\应用层序框架'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=[Security.Principal.WindowsPrincipal]::new($identity)
Add-Type @'
using System.Runtime.InteropServices;
public static class Api7DeliveryDesktop {
 [DllImport("user32.dll")] public static extern int GetSystemMetrics(int index);
 [DllImport("user32.dll")] public static extern uint GetDpiForSystem();
}
'@
$record=[ordered]@{
    date=(Get-Date).ToString('o'); commit=(& git rev-parse HEAD); dirty=[bool]@(& git status --porcelain).Count
    identity=$identity.Name; session=(Get-Process -Id $PID).SessionId
    administrator=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    os=[Environment]::OSVersion.VersionString; machineUser=(Get-CimInstance Win32_ComputerSystem).UserName
    desktop=@([Api7DeliveryDesktop]::GetSystemMetrics(0),[Api7DeliveryDesktop]::GetSystemMetrics(1))
    monitors=[Api7DeliveryDesktop]::GetSystemMetrics(80); dpi=[Api7DeliveryDesktop]::GetDpiForSystem()
    dwmPresent=[bool](Get-Process dwm -ErrorAction SilentlyContinue)
    noLoginRunnerProvided=$false; noLoginRunnerBasis='User explicitly confirmed no existing target runner'
    realImePerformed=$false; physicalMixedDpiPerformed=$false; edgeCompositionPerformed=$false; longManualPerformed=$false
    businessPilotModificationAuthorized=$false; measuredHardwareGlNeed=$false
    dependencies=@(); originalBuildFiles=@()
}
foreach($name in @('lexbor','quickjs')){
    $record.dependencies += [ordered]@{name=$name; commit=(& git -C ".deps/$name" rev-parse HEAD)}
}
foreach($file in @('.deps/mesa-24.3.4/x64/osmesa.dll','.deps/Microsoft.Web.WebView2.1.0.4129.50/build/native/include/WebView2.h')){
    $record.dependencies += [ordered]@{path=$file; sha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant()}
}
foreach($file in @(Get-ChildItem -LiteralPath build/ci-webview2 -File | Where-Object {$_.Extension -in @('.dll','.exe','.uapp')})){
    $record.originalBuildFiles += [ordered]@{path=$file.Name; sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
}
$record | ConvertTo-Json -Depth 6 | Set-Content build/api7-convergence/final-environment.json
if(!$record.administrator){
    $before=@(Get-Service -Name 'UiFrameworkSession0-*' -ErrorAction SilentlyContinue | ForEach-Object Name)
    & powershell.exe -NoProfile -File tools/run-session0-validation.ps1 -BuildDirectory build/ci-native -OSMesaLibrary .deps/mesa-24.3.4/x64/osmesa.dll -OutputDirectory build/api7-convergence/current-session0 -RequireNoLogin *> build/api7-convergence/current-session0-guard.log
    $code=$LASTEXITCODE
    $after=@(Get-Service -Name 'UiFrameworkSession0-*' -ErrorAction SilentlyContinue | ForEach-Object Name)
    [ordered]@{commit=$record.commit; exit=$code; before=$before; after=$after; serviceCreated=$false; reason='non-administrator guard precedes service creation; Session0/no-login NOT EXECUTED'} | ConvertTo-Json -Depth 4 | Set-Content build/api7-convergence/current-session0-guard.json
    if($code -ne 1 -or $before.Count -ne $after.Count -or ($before.Count -and @(Compare-Object $before $after).Count)){throw 'Unexpected Session0 guard outcome'}
}
Write-Output 'Final environment / protected-service audit recorded; missing target conditions remain pending'
