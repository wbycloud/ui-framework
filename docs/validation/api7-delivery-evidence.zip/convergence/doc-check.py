from pathlib import Path
import re, urllib.parse
root=Path.cwd()
files=['README.md','CHANGELOG.md','docs/application-development-standard.md','docs/application-upgrade-prompt.md','docs/build-and-validation.md','docs/framework-menu-offscreen.md','docs/generic-web-ui.md','docs/handoff.md','docs/workspace-layout.md','docs/migration-v0.6-to-v0.7.md','docs/business-pilot.md','docs/validation/api7-validation.md','docs/validation/runtime-stability-validation.md','docs/validation/api7-delivery-validation.md']
bad=[]
for name in files:
    path=root/name; text=path.read_text(encoding='utf-8')
    assert '@LATEST' not in text and 'RESULTS_PENDING' not in text, name
    assert text.count('```')%2==0, name
    for target in re.findall(r'\]\(([^)]+)\)',text):
        target=urllib.parse.unquote(target.split()[0].strip('<>').split('#')[0])
        if target and not re.match(r'^[a-zA-Z]+:',target) and not (path.parent/target).exists():bad.append((name,target))
assert not bad,bad
for name in ['docs/handoff.md','docs/generic-web-ui.md','docs/application-development-standard.md']:
    assert '任意嵌套/标签式停靠' not in (root/name).read_text(encoding='utf-8'),name
s=(root/'docs/handoff.md').read_text(encoding='utf-8')
prompt=s.split('可直接给下一会话以下指令：')[1].split('```')[1]
assert 'API1–7' in prompt and 'API7' in prompt and 'API6标准' not in prompt
assert 'VERSION 0.7.0' in (root/'CMakeLists.txt').read_text(encoding='utf-8')
assert '#define UI_FRAMEWORK_API_VERSION 7u' in (root/'include/ui_framework/ui.h').read_text(encoding='utf-8')
print('14 documents links/fences/placeholders PASS; current API7 entry/negative capability/version checks PASS')
