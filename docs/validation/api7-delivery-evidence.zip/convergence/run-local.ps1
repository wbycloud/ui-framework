$ErrorActionPreference = 'Stop'
$env:PATH = 'C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;' + $env:PATH
$pwsh = 'C:\Users\wbycl\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
$root = 'D:\应用软件框架\应用层序框架'
Set-Location -LiteralPath $root
$record = [ordered]@{commit=(& git rev-parse HEAD); started=(Get-Date).ToString('o'); hosted=$false; rows=@()}
foreach ($configuration in @('native','light','osmesa','webview2')) {
    foreach ($stage in @('build','test')) {
        & $pwsh -NoProfile -File tools/windows-ci.ps1 -Configuration $configuration -Stage $stage *> "build/api7-convergence/local-$configuration-$stage.log"
        $code = $LASTEXITCODE
        $record.rows += [ordered]@{configuration=$configuration; stage=$stage; exit=$code; completed=(Get-Date).ToString('o')}
        $record | ConvertTo-Json -Depth 6 | Set-Content build/api7-convergence/local-matrix-progress.json
        if ($code) { exit $code }
    }
}
$record.completed = (Get-Date).ToString('o')
$record | ConvertTo-Json -Depth 6 | Set-Content build/api7-convergence/local-matrix-progress.json
