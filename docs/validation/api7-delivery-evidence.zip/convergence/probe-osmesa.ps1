$ErrorActionPreference='Stop'
$root='D:\应用软件框架\应用层序框架'
Set-Location -LiteralPath $root
$build=Join-Path $root 'build/ci-osmesa'
$directory=Join-Path $root 'build/api7-convergence/osmesa-isolation'
[void][IO.Directory]::CreateDirectory($directory)
$stash=Join-Path $build 'wgl-deployment'
[void][IO.Directory]::CreateDirectory($stash)
$files=@('opengl32.dll','libgallium_wgl.dll','libglapi.dll','pipe_swrast.dll')
foreach($file in $files){Move-Item -LiteralPath (Join-Path $build $file) -Destination (Join-Path $stash $file)}
$results=[ordered]@{commit=(& git rev-parse HEAD); runnerHash=(Get-FileHash "$build/ui_session0_gl_test.exe").Hash; mode='provider-only; four application-local WGL DLLs isolated'; runs=@()}
try {
    for($i=1;$i -le 3;++$i){
        $out=Join-Path $directory "run-$i"
        [void][IO.Directory]::CreateDirectory($out)
        & "$build/ui_session0_gl_test.exe" "$build/session0_gl_app.uapp" "$root/.deps/mesa-24.3.4/x64/osmesa.dll" $out --allow-interactive
        $results.runs += [ordered]@{run=$i; exit=$LASTEXITCODE; time=(Get-Date).ToString('o')}
        $results | ConvertTo-Json -Depth 5 | Set-Content "$directory/progress.json"
    }
} finally {foreach($file in $files){Move-Item -LiteralPath (Join-Path $stash $file) -Destination (Join-Path $build $file)}}
