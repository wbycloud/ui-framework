﻿$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $taskRoot
$ev='build/component-scroll-only-evidence/matrix-final-webview2'
New-Item -ItemType Directory -Force $ev|Out-Null
foreach($stage in @('build','test')){
  $ErrorActionPreference='Continue'
  & 'C:/Users/wbycl/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe' -NoProfile -ExecutionPolicy Bypass -File tools/windows-ci.ps1 -Configuration webview2 -Stage $stage -EvidenceDirectory $ev *> "$ev/stage-$stage.log"
  $code=$LASTEXITCODE
  $ErrorActionPreference='Stop'
  $code|Set-Content "$ev/stage-$stage.exit"
  if($code){throw "Final webview2 $stage failed ($code)"}
}
& 'C:/Users/wbycl/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe' -NoProfile -ExecutionPolicy Bypass -File build/component-scroll-only-evidence/after.ps1
$LASTEXITCODE|Set-Content (Join-Path $PSScriptRoot 'after-script.exit')
