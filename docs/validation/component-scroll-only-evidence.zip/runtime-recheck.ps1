﻿$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $taskRoot
$ctest='C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
@{commit=(& git rev-parse HEAD);status=@(& git status --porcelain);utc=[DateTime]::UtcNow.ToString('o');test_sha256=(Get-FileHash build/ci-webview2/ui_webview2_render_test.exe).Hash;runtime_sha256=(Get-FileHash build/ci-webview2/ui_framework.dll).Hash}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'runtime-recheck-identity.json')
$ErrorActionPreference='Continue'
foreach($i in 1..3){
  $prefix=Join-Path $PSScriptRoot "runtime-independent-$i"
  & $ctest --test-dir build/ci-webview2 --output-on-failure --output-junit "$prefix.xml" -R '^ui_webview2_render$' *> "$prefix.log"
  $LASTEXITCODE|Set-Content "$prefix.exit"
  Copy-Item -LiteralPath build/ci-webview2/Testing/Temporary/LastTest.log -Destination "$prefix-LastTest.log"
}
$prefix=Join-Path $PSScriptRoot 'runtime-phase-recheck'
& $ctest --test-dir build/ci-webview2 --output-on-failure --output-junit "$prefix.xml" -R 'ui_webview2_|ui_component_experience_webview2|ui_component_scroll_webview2|ui_api7_integration_webview2|ui_visual_ui_webview2' *> "$prefix.log"
$LASTEXITCODE|Set-Content "$prefix.exit"
Copy-Item -LiteralPath build/ci-webview2/Testing/Temporary/LastTest.log -Destination "$prefix-LastTest.log"
0|Set-Content (Join-Path $PSScriptRoot 'runtime-recheck.done')
