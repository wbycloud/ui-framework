from PIL import Image
from pathlib import Path
import json, hashlib
root=Path(__file__).resolve().parents[2]
ev=Path(__file__).resolve().parent
out=root/'docs/validation'
items=[]
for mode in ('light','webview2'):
    for surface in ('host-light','host-dark','table-light-96','table-dark-96','tree-light'):
        for phase in ('before','after'):
            source=ev/f'{phase}-{mode}-{surface}.bmp'
            target=out/f'component-scroll-{phase}-{mode}-{surface}.png'
            image=Image.open(source).convert('RGB')
            image.save(target)
            assert Image.open(target).convert('RGB').tobytes()==image.tobytes()
            items.append(dict(source=source.name,png=target.name,size=image.size,bmp_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),png_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),rgb_pixels_equal=True))
(ev/'screenshot-index.json').write_text(json.dumps(items,indent=2),encoding='utf-8')
print(f'{len(items)} actual BMP -> PNG; RGB pixels unchanged')
