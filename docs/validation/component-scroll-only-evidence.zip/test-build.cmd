@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
cmake --build build/ci-webview2 --target ui_component_scroll_test ui_visual_ui_test >build/component-scroll-only-evidence/test-build.log 2>&1
exit /b %errorlevel%
