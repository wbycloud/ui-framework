﻿$ErrorActionPreference='Stop'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$ctest='C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
$build=Join-Path $root 'build/ci-webview2'
@{commit=(& git -C $root rev-parse HEAD);status=@(& git -C $root status --porcelain);utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 4|Set-Content (Join-Path $PSScriptRoot 'pager-final-identity.json') -Encoding UTF8
$ErrorActionPreference='Continue'
& $ctest --test-dir $build --output-on-failure --output-junit (Join-Path $PSScriptRoot 'pager-final.xml') -R '^(ui_component_scroll|ui_component_scroll_webview2|ui_visual_ui_light|ui_visual_ui_webview2)$' *> (Join-Path $PSScriptRoot 'pager-final.log')
$LASTEXITCODE|Set-Content (Join-Path $PSScriptRoot 'pager-final.exit')
Copy-Item -LiteralPath (Join-Path $build 'Testing/Temporary/LastTest.log') -Destination (Join-Path $PSScriptRoot 'pager-final-LastTest.log')
