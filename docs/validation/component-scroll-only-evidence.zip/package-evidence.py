from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2]
ev=Path(__file__).resolve().parent
out=root/'docs/validation/component-scroll-only-evidence.zip'
files=sorted(p for p in ev.rglob('*') if p.is_file() and p.name not in ('evidence-index.json','archive-check.json'))
index=[dict(path=p.relative_to(ev).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
(ev/'evidence-index.json').write_text(json.dumps(index,indent=2),encoding='utf-8')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[ev/'evidence-index.json']:
        z.write(p,p.relative_to(ev).as_posix())
with zipfile.ZipFile(out) as z:
    for entry in index:
        actual=z.read(entry['path'])
        assert len(actual)==entry['bytes'] and hashlib.sha256(actual).hexdigest()==entry['sha256']
        assert actual==(ev/entry['path']).read_bytes()
result=dict(files=len(index),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),all_raw_bytes_equal=True)
(ev/'archive-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
