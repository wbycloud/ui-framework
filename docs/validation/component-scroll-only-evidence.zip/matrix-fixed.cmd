@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
"C:\Users\wbycl\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe" -NoProfile -ExecutionPolicy Bypass -File build\component-scroll-only-evidence\matrix-fixed.ps1 >build\component-scroll-only-evidence\matrix-fixed-launch.log 2>&1
exit /b %errorlevel%
