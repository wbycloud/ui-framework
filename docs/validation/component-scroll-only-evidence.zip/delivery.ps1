﻿$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $taskRoot
$ev='build/component-scroll-only-evidence/matrix-delivery-webview2'
New-Item -ItemType Directory -Force $ev|Out-Null
foreach($stage in @('build','test')){
  $ErrorActionPreference='Continue'
  & 'C:/Users/wbycl/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe' -NoProfile -ExecutionPolicy Bypass -File tools/windows-ci.ps1 -Configuration webview2 -Stage $stage -EvidenceDirectory $ev *> "$ev/stage-$stage.log"
  $code=$LASTEXITCODE
  $ErrorActionPreference='Stop'
  $code|Set-Content "$ev/stage-$stage.exit"
  if($code){throw "Delivery webview2 $stage failed ($code)"}
}
0|Set-Content (Join-Path $PSScriptRoot 'delivery.done')
