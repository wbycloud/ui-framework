﻿$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $taskRoot
$ev='build/component-scroll-only-evidence/matrix-delivery-webview2'
New-Item -ItemType Directory -Force $ev|Out-Null
foreach($stage in @('build','test')){
  $ErrorActionPreference='Continue'
  0|Set-Content (Join-Path $PSScriptRoot 'delivery.done')
