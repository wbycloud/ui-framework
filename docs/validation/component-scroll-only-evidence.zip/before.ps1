﻿$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$build=Join-Path $taskRoot 'build/ci-webview2'
$identity=[ordered]@{commit=(& git -C $taskRoot rev-parse HEAD);utc=[DateTime]::UtcNow.ToString('o');status=@(& git -C $taskRoot status --porcelain);os=[Environment]::OSVersion.VersionString;files=@()}
foreach($relative in @('ui_framework.dll','ui_visual_ui_test.exe','api7_fixture.uapp','ui_api7_fixture.dll')){$path=Join-Path $build $relative;$identity.files+=@{name=$relative;bytes=(Get-Item $path).Length;sha256=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([IO.File]::ReadAllBytes($path))).Replace('-','').ToLowerInvariant()}}
$identity|ConvertTo-Json -Depth 6|Set-Content (Join-Path $PSScriptRoot 'before-identity.json') -Encoding UTF8
$ErrorActionPreference='Continue'
foreach($mode in @('light','webview2')){& (Join-Path $build 'ui_visual_ui_test.exe') (Join-Path $build 'api7_fixture.uapp') (Join-Path $taskRoot '.deps/mesa-24.3.4/x64/osmesa.dll') $mode (Join-Path $PSScriptRoot ('before-'+$mode)) *> (Join-Path $PSScriptRoot ('before-'+$mode+'.log'));$LASTEXITCODE|Set-Content (Join-Path $PSScriptRoot ('before-'+$mode+'.exit'))}
