﻿$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
Set-Location ../..
foreach($row in @('native','light','osmesa','webview2')) {
  $ev="build/component-scroll-only-evidence/matrix-fixed-$row"
  New-Item -ItemType Directory -Force $ev|Out-Null
  foreach($stage in @('build','test')) {
    $ErrorActionPreference='Continue'
    & "C:/Users/wbycl/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe" -NoProfile -ExecutionPolicy Bypass -File tools/windows-ci.ps1 -Configuration $row -Stage $stage -EvidenceDirectory $ev *> "$ev/stage-$stage.log"
    $code=$LASTEXITCODE
    $ErrorActionPreference='Stop'
    $code|Set-Content "$ev/stage-$stage.exit"
    if($code) { throw "Row $row stage $stage failed ($code)" }
  }
}
0|Set-Content build/component-scroll-only-evidence/matrix-fixed.exit
